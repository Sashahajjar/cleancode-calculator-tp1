package org.isep.cleancode;

import org.isep.cleancode.calculator.Calculator;

public class Main {
    public static void main(String[] args) {
        // Créer une instance de la calculatrice
        Calculator calculator = new Calculator();

        // Liste des expressions à tester pour couvrir toutes les fonctionnalités
        String[] expressions = {
            "3 + 5",                // Addition
            "10 - 4",               // Soustraction
            "6 * 7",                // Multiplication
            "20 / 5",               // Division
            "1 + 2 * 3",            // Précédence des opérateurs
            "(1 + 2) * 3",          // Parenthèses
            "10 - (2 + 3)",         // Parenthèses avec soustraction
            "-5 + 3",               // Nombre négatif
            "-3 * 4",               // Nombre négatif avec multiplication
            "(5 - 10) / 5",         // Résultat négatif avec parenthèses
            "2 + 3 * (4 - 2)",      // Opérations mixtes et parenthèses
            "(2 + 3) * (4 + 1)",    // Structure de parenthèses imbriquées
            "((2 + 3) * 2) + 1",    // Parenthèses imbriquées
            "3.14 + 2.86",          // Addition de nombres décimaux
            "10 / 3",               // Division avec nombre décimal
            "5 / 2",                // Autre division avec nombre décimal
            "10.5 - 5.2",           // Soustraction de nombres décimaux
            "(5.5 + 2.5) * 3",      // Opération avec parenthèses et nombres décimaux
            "2.1 * 3",              // Multiplication avec nombre décimal
            "8 / (4 - 2)"           // Division avec parenthèses
        };

        // Évaluer et afficher les résultats
        for (String expr : expressions) {
            double result = calculator.evaluateMathExpression(expr);
            System.out.println("Expression: " + expr + " = " + result);
        }
    }
}
