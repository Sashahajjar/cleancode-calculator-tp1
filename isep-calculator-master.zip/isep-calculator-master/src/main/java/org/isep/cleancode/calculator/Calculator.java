package org.isep.cleancode.calculator;

import java.util.*;

public class Calculator {

    // expression mathématique
    public double evaluateMathExpression(String expression) {
        expression = expression.replaceAll("\\s+", ""); // Supprimer les espaces
        return evaluate(expression); // Évaluer l'expression
    }

    // expressions avec des parenthèses
    private double evaluate(String expr) {
        while (expr.contains("(")) {
            int open = expr.lastIndexOf("(");
            int close = expr.indexOf(")", open);
            String inside = expr.substring(open + 1, close);
            double innerResult = evaluate(inside); // Résultat de l'intérieur des parenthèses
            expr = expr.substring(0, open) + innerResult + expr.substring(close + 1); // Remplacer par le résultat
        }
        return evaluateSimpleExpression(expr); // Évaluer l'expression sans parenthèses
    }

    // arrondir les résultats à deux décimales
    private double roundToTwoDecimalPlaces(double value) {
        return Math.round(value * 100.0) / 100.0;
    }

    // expressions simples (+, -, *, /)
    private double evaluateSimpleExpression(String expr) {
        List<Double> numbers = new ArrayList<>();
        List<Character> operators = new ArrayList<>();

        if (expr.startsWith("-")) { // Gérer les nombres négatifs
            expr = "0" + expr;
        }

        int i = 0;
        StringBuilder number = new StringBuilder();

        while (i < expr.length()) {
            char c = expr.charAt(i);
            if (Character.isDigit(c) || c == '.') {
                number.append(c); // Ajouter le chiffre au nombre
            } else {
                numbers.add(Double.parseDouble(number.toString())); // Ajouter le nombre
                number.setLength(0); // Réinitialiser le nombre
                operators.add(c); // Ajouter l'opérateur
            }
            i++;
        }

        numbers.add(Double.parseDouble(number.toString())); // Ajouter le dernier nombre

        // gérer la multiplication et la division
        for (int j = 0; j < operators.size(); j++) {
            char op = operators.get(j);
            if (op == '*' || op == '/') {
                double left = numbers.get(j);
                double right = numbers.get(j + 1);
                double result = (op == '*') ? left * right : left / right;
                numbers.set(j, result);
                numbers.remove(j + 1);
                operators.remove(j);
                j--;
            }
        }

        //  gérer l'addition et la soustraction
        double result = numbers.get(0);
        for (int j = 0; j < operators.size(); j++) {
            char op = operators.get(j);
            if (op == '+') {
                result += numbers.get(j + 1);
            } else if (op == '-') {
                result -= numbers.get(j + 1);
            }
        }

        return roundToTwoDecimalPlaces(result); // Retourner le résultat arrondi
    }
}
